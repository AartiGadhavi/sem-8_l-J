﻿namespace UserManagement.Models.Errors
{
    public class ErrorMessages
    {
        public const string UserNotFound = "Kullanıcı bulunamadı!";
        public const string UsersNotFound = "Kullanıcılar bulunamadı!";
    }
}
