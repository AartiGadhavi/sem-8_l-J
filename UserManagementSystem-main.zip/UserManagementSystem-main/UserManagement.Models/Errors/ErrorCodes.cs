﻿namespace UserManagement.Models.Errors
{
    public enum ErrorCodes
    {
        UserNotFound = 1001,
        UsersNotFound = 1002,

    }
}
